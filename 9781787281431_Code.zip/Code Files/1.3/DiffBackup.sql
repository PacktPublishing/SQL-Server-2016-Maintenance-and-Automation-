-- Backup Demo
-- Create a logging table
CREATE TABLE BackupLog
( logdate DATETIME2 DEFAULT SYSDATETIME()
, logmessage VARCHAR(200)
)


-- add a message
INSERT dbo.BackupLog
        ( logdate, logmessage )
    VALUES ( SYSDATETIME(), '1st Log, before a backup' )
GO

-- Create a table and load some data
CREATE TABLE MyBigTable
( myid INT
, myname VARCHAR(20)
, mychar VARCHAR(2000)  
)
;
go
DECLARE @i INT = 65;
WHILE @i < 92
 begin
  INSERT dbo.MyBigTable
          SELECT @i, 'SQL Server', REPLICATE(CHAR(@i), 2000);
  SELECT @i = @i + 1;
 END
;
GO





--  Run a backup to get the initial size.
BACKUP DATABASE Packt TO disk = 'Packt.bak'
GO




-- BACKUP DATABASE successfully processed 462 pages in 0.407 seconds (8.857 MB/sec)
-- BACKUP DATABASE WITH DIFFERENTIAL successfully processed 123 pages in 0.187 seconds (5.104 MB/sec).
-- BACKUP DATABASE WITH DIFFERENTIAL successfully processed 137 pages in 0.100 seconds (10.659 MB/sec).

-- Log the event
INSERT dbo.BackupLog
        ( logdate, logmessage )
    VALUES ( SYSDATETIME(), '2nd Log, after full backup' )
GO
-- Update some pages
UPDATE dbo.MyBigTable
 SET mychar = REPLICATE('A', 2000)
 WHERE myid < 76



 -- Log the event
INSERT dbo.BackupLog
        ( logdate, logmessage )
    VALUES ( SYSDATETIME(), '3rd Log, before diff backup' )
GO


-- Run a Differential backup
BACKUP DATABASE Packt TO DISK = 'Packt_a.dff' WITH DIFFERENTIAL


GO
-- Log the event
INSERT dbo.BackupLog
        ( logdate, logmessage )
    VALUES ( SYSDATETIME(), '4th Log, after first diff backup' )
GO





-- Update more pages
UPDATE dbo.MyBigTable
 SET mychar = REPLICATE('A', 2000)
 WHERE myid < 90



-- Run a Differential backup
BACKUP DATABASE Packt TO DISK = 'Packt_b.dff' WITH DIFFERENTIAL
GO


-- Log the event
INSERT dbo.BackupLog
        ( logdate, logmessage )
    VALUES ( SYSDATETIME(), '5th Log, after second diff backup' )
GO
