-- Log Backup Demo
SELECT *
 FROM BackupLog
GO



-- add a message
INSERT dbo.BackupLog
        ( logdate, logmessage )
    VALUES ( SYSDATETIME(), '6th Log, before 1st log backup' )
GO

BACKUP LOG Packt TO DISK = 'Packt_a.trn' WITH CHECKSUM;
GO




-- add a message
INSERT dbo.BackupLog
        ( logdate, logmessage )
    VALUES ( SYSDATETIME(), '7th Log, between log backups 1 and 2' )
GO
BACKUP LOG Packt TO DISK = 'Packt_b.trn' WITH CHECKSUM;
GO




-- update data
UPDATE dbo.MyBigTable
 SET mychar = REPLICATE('Z', 2000)
 WHERE myid < 76
GO
-- add a message
INSERT dbo.BackupLog
        ( logdate, logmessage )
    VALUES ( SYSDATETIME(), '8th Log, between log backups 2 and 3' )
GO
BACKUP LOG Packt TO DISK = 'Packt_c.trn' WITH CHECKSUM;
GO
INSERT dbo.BackupLog
        ( logdate, logmessage )
    VALUES ( SYSDATETIME(), '9th Log, after log backup 3' )
GO
SELECT top 10
 *
 FROM dbo.BackupLog
 