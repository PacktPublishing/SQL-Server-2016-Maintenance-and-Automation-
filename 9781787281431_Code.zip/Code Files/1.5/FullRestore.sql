-- Restore Database Demo
USE Packt
GO
SELECT * FROM BackupLog






-- Perform restore from SSMS
USE master
GO




-- perform same restore from T-SQL
USE master
GO
RESTORE DATABASE Packt
 FROM DISK = 'Packt.bak'
 WITH NORECOVERY;
 GO
RESTORE DATABASE Packt
 FROM DISK = 'Packt_b.dff'
 WITH NORECOVERY;
 GO
 RESTORE DATABASE Packt WITH RECOVERY;
 GO
 USE Packt
 GO
 SELECT * FROM BackupLog
 GO
 