-- Restore transaction logs
USE Packt
GO
SELECT top 10
 *
 FROM dbo.BackupLog
 GO
 


-- change database and restore full and diff
USE master
GO
RESTORE DATABASE Packt
 FROM DISK = 'Packt.bak'
 WITH NORECOVERY;
 GO
RESTORE DATABASE Packt
 FROM DISK = 'Packt_b.dff'
 WITH NORECOVERY;
 GO
 RESTORE LOG Packt
 FROM DISK = 'Packt_a.trn'
 WITH NORECOVERY;
 GO
 RESTORE LOG Packt
 FROM DISK = 'Packt_b.trn'
 WITH NORECOVERY;
 GO
 RESTORE LOG Packt
 FROM DISK = 'Packt_c.trn'
 WITH NORECOVERY;
 GO
 RESTORE DATABASE Packt WITH RECOVERY