-- Restore to a point in time.
USE Packt
GO
SELECT top 20
 *
 FROM dbo.BackupLog
GO




-- Get a starting point.
BACKUP DATABASE Packt TO disk = 'Pack_2.bak'
GO


-- We need some transactions over time. Let's get some
DECLARE @seconds INT = 10,
        @starttime DATETIME2 = SYSDATETIME();

WHILE (SYSDATETIME() < DATEADD( SECOND, @seconds, @starttime))
 BEGIN
  INSERT dbo.BackupLog
        ( logdate, logmessage )
    VALUES ( SYSDATETIME(), 'Log record entered at ' + CAST(SYSDATETIME() AS VARCHAR(30)) )
  WAITFOR DELAY '00:00:01'
 END
 
SELECT 
  *
  FROM dbo.BackupLog
GO
  
  
 -- Make a log backup
 BACKUP LOG Packt TO DISK = 'Packt_Pointintime.trn'
 GO
 
 -- restore in SSMS

